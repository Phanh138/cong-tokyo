/**
 * CỘNG TOKYO — Bộ nhận bình chọn cho Google Sheets.
 * Hướng dẫn triển khai ở README.md.
 * Không thu tên, email hoặc vị trí của người tham dự.
 */
const SHEET_NAME = 'Votes';
const ALLOWED_IDS = ['coconut', 'phin', 'matcha', 'sakura'];

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['Thời gian', 'Mã đồ uống']);
  }
  return sheet;
}

function doPost(e) {
  try {
    const data = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!ALLOWED_IDS.includes(data.drinkId)) {
      return ContentService.createTextOutput('invalid');
    }
    getSheet_().appendRow([new Date(), data.drinkId]);
    return ContentService.createTextOutput('ok');
  } catch (error) {
    return ContentService.createTextOutput('error');
  }
}

function doGet(e) {
  const callback = (e && e.parameter && e.parameter.callback) || 'congCallback';
  if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(callback)) {
    return ContentService.createTextOutput('invalid callback');
  }
  const sheet = getSheet_();
  const lastRow = sheet.getLastRow();
  const counts = { coconut: 0, phin: 0, matcha: 0, sakura: 0 };
  if (lastRow > 1) {
    const rows = sheet.getRange(2, 2, lastRow - 1, 1).getValues();
    rows.forEach(row => {
      const key = String(row[0] || '');
      if (Object.prototype.hasOwnProperty.call(counts, key)) counts[key]++;
    });
  }
  const payload = JSON.stringify({counts});
  return ContentService
    .createTextOutput(callback + '(' + payload + ');')
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}
